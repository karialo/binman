# rsync-backup

Quick backup to a target device with snapshot folder named by date

Author: K.A.R.I

## Usage
```
rsync-backup [args]
```
